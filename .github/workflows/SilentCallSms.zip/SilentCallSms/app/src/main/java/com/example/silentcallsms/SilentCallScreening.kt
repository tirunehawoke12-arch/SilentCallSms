package com.example.silentcallsms

import android.telecom.Call
import android.telecom.CallScreeningService
import android.telephony.SmsManager

class SilentCallScreening : CallScreeningService() {

    override fun onScreenCall(callDetails: Call.Details) {
        val rawNumber = callDetails.handle?.schemeSpecificPart
        val prefs = getSharedPreferences("settings", MODE_PRIVATE)

        // የቤተሰብ ቁጥር ከሆነ ጥሪው እንዲደርስ ይፈቅዳል
        val familyList = prefs.getString("family_numbers", "") ?: ""
        val familyNumbers = familyList.split(",").map { it.trim() }.filter { it.isNotBlank() }
        if (rawNumber != null && familyNumbers.any { sameNumber(it, rawNumber) }) {
            respondToCall(callDetails, CallScreeningService.CallResponse.Builder().build())
            return
        }

        val number = rawNumber ?: "ያልታወቀ ቁጥር"

        // ለሌሎች ጥሪዎች ውድቅ ያደርጋል፣ ስልኩ አይጮኽም
        val response = CallScreeningService.CallResponse.Builder()
            .setDisallowCall(true)
            .setRejectCall(true)
            .setSkipCallLog(false)
            .setSkipNotification(true)
            .build()
        respondToCall(callDetails, response)

        // ያስቀመጥከውን ቁጥር ብቻ SMS ይልካል
        val myNumber = prefs.getString("my_number", "") ?: ""
        if (myNumber.isNotBlank()) {
            try {
                SmsManager.getDefault().sendTextMessage(
                    myNumber, null, "ጥሪ ከ: $number", null, null
                )
            } catch (e: Exception) {
                // SMS ፍቃድ ካልተሰጠ ጥሪው አሁንም ውድቅ ይሆናል
            }
        }
    }

    // ቁጥሮችን ከ+ ፣ ክፍተትና ሰረዝ ነጻ አድርጎ የመጨረሻዎቹን 9 አሃዞች ያወዳድራል
    private fun sameNumber(a: String, b: String): Boolean {
        val da = a.filter { it.isDigit() }
        val db = b.filter { it.isDigit() }
        if (da.length < 7 || db.length < 7) return false
        return da.takeLast(9) == db.takeLast(9)
    }
}
