package com.example.silentcallsms

import android.Manifest
import android.app.role.RoleManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var status: TextView

    private val roleLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { refreshStatus() }

    private val smsLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { refreshStatus() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        status = findViewById(R.id.status)
        val numberInput = findViewById<EditText>(R.id.numberInput)
        val familyInput = findViewById<EditText>(R.id.familyInput)
        val prefs = getSharedPreferences("settings", Context.MODE_PRIVATE)

        numberInput.setText(prefs.getString("my_number", ""))
        familyInput.setText(prefs.getString("family_numbers", ""))

        findViewById<Button>(R.id.saveButton).setOnClickListener {
            prefs.edit()
                .putString("my_number", numberInput.text.toString().trim())
                .putString("family_numbers", familyInput.text.toString().trim())
                .apply()
            Toast.makeText(this, "ተቀምጧል", Toast.LENGTH_SHORT).show()
        }

        findViewById<Button>(R.id.roleButton).setOnClickListener {
            val rm = getSystemService(RoleManager::class.java)
            if (!rm.isRoleHeld(RoleManager.ROLE_CALL_SCREENING)) {
                roleLauncher.launch(rm.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING))
            }
        }

        findViewById<Button>(R.id.smsButton).setOnClickListener {
            smsLauncher.launch(Manifest.permission.SEND_SMS)
        }

        refreshStatus()
    }

    private fun refreshStatus() {
        val rm = getSystemService(RoleManager::class.java)
        val role = if (rm.isRoleHeld(RoleManager.ROLE_CALL_SCREENING)) "✅" else "❌"
        val sms = if (checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) "✅" else "❌"
        status.text = "ጥሪ ማጣሪያ: $role\nSMS ፍቃድ: $sms"
    }
}
